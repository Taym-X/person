# Don't flash in recovery!
if ! $BOOTMODE; then
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU / APatch app"
    abort    "*********************************************************"
fi

# Error on < Android 8
if [ "$API" -lt 26 ]; then
    abort "! You can't use this module on Android < 8.0"
fi

check_zygisk() {
    local ZYGISK_MODULE="/data/adb/modules/zygisksu"
    local REZYGISK_MODULE="/data/adb/modules/rezygisk"
    local MAGISK_DIR="/data/adb/magisk"
    local ZYGISK_MSG="Zygisk is not enabled. Please either:
    - Enable Zygisk in Magisk settings
    - Install ZygiskNext or ReZygisk module"

    # Check if Zygisk module directory exists
    if [ -d "$ZYGISK_MODULE" ] || [ -d "$REZYGISK_MODULE" ]; then
        return 0
    fi

    # If Magisk is installed, check Zygisk settings
    if [ -d "$MAGISK_DIR" ]; then
        # Query Zygisk status from Magisk database
        local ZYGISK_STATUS
        ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';")

        # Check if Zygisk is disabled
        if [ "$ZYGISK_STATUS" = "value=0" ]; then
            abort "$ZYGISK_MSG"
        fi
    else
        abort "$ZYGISK_MSG"
    fi
}

# Module requires Zygisk to work
check_zygisk

# safetynet-fix module is obsolete and it's incompatible with PIF
SNFix="/data/adb/modules/safetynet-fix"
if [ -d "$SNFix" ]; then
    ui_print "! safetynet-fix module is obsolete and it's incompatible with PIF, it will be removed on next reboot"
    ui_print "! Do not install it"
    touch "$SNFix"/remove
fi

# playcurl warn
if [ -d "/data/adb/modules/playcurl" ]; then
    ui_print "! playcurl may overwrite fingerprint with invalid one, be careful!"
fi

# MagiskHidePropsConf module is obsolete in Android 8+ but it shouldn't give issues
if [ -d "/data/adb/modules/MagiskHidePropsConf" ]; then
    ui_print "! WARNING, MagiskHidePropsConf module may cause issues with PIF."
fi

# Preserve previous setting
spoofConfig="spoofVendingSdk"
for config in $spoofConfig; do
    grep -q "$config" "/data/adb/modules/playintegrityfix/pif.json" || continue
    if grep -q "\"$config\": true" "/data/adb/modules/playintegrityfix/pif.json"; then
        sed -i "s/\"$config\": .*/\"$config\": true,/" "$MODPATH/pif.json"
    else
        sed -i "s/\"$config\": .*/\"$config\": false,/" "$MODPATH/pif.json"
    fi
done
sed -i ':a;N;$!ba;s/,\n}/\n}/g' "$MODPATH/pif.json"

# Check custom fingerprint
if [ -f "/data/adb/pif.json" ]; then
    mv -f "/data/adb/pif.json" "/data/adb/pif.json.old"
        ui_print "- Welcome "
fi
ui_print "- ⭐ This Modules Developers By @AboSadekX "
ui_print "- 🥊 Built-In BusyBox 🛠️"
ui_print "- 🔥 Device Integrity ✅"
ui_print "- 🎭 Add New KeyBox 🛸"
ui_print "- 💢 Hide Apps Auto ⭐"
ui_print "- 📞 Telegram : @AboSadekX "

# Start Random KeyBox By @AboSadekX ⭐
 Start Random KeyBox By @AboSadekX ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/keybox.xml" ]; then
  backup_file "$CONFIG_DIR/keybox.xml"
  rm "/data/adb/tricky_store/keybox.xml"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.@AboSadekX" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .@AboSadekX files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/keybox.xml" 

su -c killall com.google.android.gms
su -c killall com.google.android.gms.unstable

# End Random KeyBox Script ⭐

# Start Bootloader&Spoofer Script ⭐
 Start Random KeyBox By @AboSadekX ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/target.txt" ]; then
  backup_file "$CONFIG_DIR/target.txt"
  rm "/data/adb/tricky_store/target.txt"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.x" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .x files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/target.txt"
# End Bootloader&Spoofer Script ⭐

# Start security_patch Script ⭐
 Start Random security_patch By @AboSadekX ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/security_patch.txt" ]; then
  backup_file "$CONFIG_DIR/security_patch.txt"
  rm "/data/adb/tricky_store/security_patch.txt"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.security_patch.txt" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .security_patch.txt files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/security_patch.txt"
# End security_patch Script ⭐

# Start system_app Script ⭐
 Start Random system_app By @AboSadekX ⭐
unzip -o "$ZIPFILE" 'zygisk/*' -d "$MODPATH/zygisk" > /dev/null 2>&1

if [ -f "/data/adb/tricky_store/system_app" ]; then
  backup_file "$CONFIG_DIR/system_app"
  rm "/data/adb/tricky_store/system_app"
fi
random_keybox=$(find "$MODPATH/zygisk" -type f -name "*.system_app" | shuf -n 1)
if [ -z "$random_keybox" ]; then
    abort "Error: No .system_app files found"
    exit 1
fi
cp "$random_keybox" "/data/adb/tricky_store/system_app"
# End system_app Script ⭐

# Start Change BusyBox Modules To Built-In BusyBox ⭐
if [ -d "/data/adb/modules/busybox-ndk" ]; then
    touch "/data/adb/modules/busybox-ndk/remove"
    ui_print
fi
# End Change BusyBox Script ⭐

# Start Auto Hide App Script ⭐
su -c "magisk --whitelist add com.pshmods.gg com.pshmods.gg"

# give exec perm to action.sh
chmod +x "$MODPATH/action.sh"

