  #!/system/bin/sh
echo "
             اللهم صّلِ وسَلّمْ عَلۓِ نَبِيْنَامُحَمد ﷺ
╗────────────────────────────────────────╔
             Telegram : @AboSadekX
╝────────────────────────────────────────╚
"
sleep 3
#KeyBox By @AboSadekX 🔑
TRICKY_DIR="/data/adb/tricky_store"
TARGET_FILE="$TRICKY_DIR/keybox.xml"
BACKUP_FILE="$TRICKY_DIR/keybox.xml.bak"
REMOTE_URL="https://raw.githubusercontent.com/Taym-X/person/refs/heads/main/k"

ui_print() {
  echo "$1"
}



override_keybox() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$REMOTE_URL" | base64 -d > "$TARGET_FILE"  && ui_print "- 📲 Successfully Updating All Done! 💯"
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$REMOTE_URL" | base64 -d > "$TARGET_FILE" && ui_print "- keybox.xml successfully updated."
  else
    ui_print "- Error: curl or wget not available."
    ui_print "- Cannot fetch remote keybox."
  fi
}

# Start logic
ui_print "⚓ Upgrading 🎗️KeyBox🎗️PIF🎗️Strong🎗️Target🎗️ 🛡️"

mkdir -p "$TRICKY_DIR"

if [ -f "$TARGET_FILE" ]; then
  if grep -q "MRootSu" "$TARGET_FILE"; then
    ui_print
    version
    override_keybox
  else
    ui_print
    mv "$TARGET_FILE" "$BACKUP_FILE"
    version
    override_keybox
  fi
else
  ui_print
  touch "$TARGET_FILE"
  version
  override_keybox
fi
#PIF By @AboSadekX ✅
TRICKY_DIR="/data/adb"
TARGET_FILE="$TRICKY_DIR/pif.json"
BACKUP_FILE="$TRICKY_DIR/pif.json.bak"
REMOTE_URL="https://raw.githubusercontent.com/Taym-X/person/refs/heads/main/p"

ui_print() {
  echo "$1"
}



override_keybox() {
  ui_print
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$REMOTE_URL" | base64 -d > "$TARGET_FILE"  && ui_print
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$REMOTE_URL" | base64 -d > "$TARGET_FILE" && ui_print "- keybox.xml successfully updated."
  else
    ui_print "- Error: curl or wget not available."
    ui_print "- Cannot fetch remote keybox."
  fi
}

# Start logic
ui_print

mkdir -p "$TRICKY_DIR"

if [ -f "$TARGET_FILE" ]; then
  if grep -q "MRootSu" "$TARGET_FILE"; then
    ui_print
    version
    override_keybox
  else
    ui_print
    mv "$TARGET_FILE" "$BACKUP_FILE"
    version
    override_keybox
  fi
else
  ui_print
  touch "$TARGET_FILE"
  version
  override_keybox
fi

echo
echo
echo
echo
sleep_pause